//
//  ViewController.swift
//  tableviewcontroller
//
//  Created by MACOS on 11/19/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    var arr:[String]? = nil;
    var img:[String]? = nil;
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        arr = ["apple","iphone","mac","ios","ipad","ipod"];
        img  = ["IMAGE.jpg","IMAGE.jpg","IMAGE.jpg","IMAGE.jpg","IMAGE.jpg","IMAGE.jpg","IMAGE.jpg","IMAGE.jpg"];
    }

    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return (arr?.count)!;
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath);
        cell.textLabel?.text = arr?[indexPath.row]
        cell.accessoryType = UITableViewCellAccessoryType.detailDisclosureButton;
        
        cell.imageView?.image = UIImage(named: (img?[indexPath.row])!);
        
        return cell;
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        print(arr?[indexPath.row]);
    }
    
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        
        return "tops";
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        return "tech";
        
    }

    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        
        
        arr?.remove(at: indexPath.row);
        
        tableView.reloadData();
        
        
    }

    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        
        let ok = UITableViewRowAction(style: UITableViewRowActionStyle.default, title: "Ok") { (uitableviewrowaction, indexpath) in
            
            print("ok button press");
            
            
        }
        let cancal = UITableViewRowAction(style: UITableViewRowActionStyle.destructive, title: "cancal") { (uitableviewrowactrion, indexpth) in
            
            print("cancal press");
            
        }
        
        return [ok,cancal];
        
    }
    
   //custome header and footer design
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        
        
        
        let v1 = UIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 45));
        
        v1.backgroundColor = #colorLiteral(red: 0.7860680223, green: 0.4232106507, blue: 0.4361130595, alpha: 1)
        
        return v1;
        
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let v1 = UIView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 45));
        
        v1.backgroundColor = #colorLiteral(red: 0.2392156869, green: 0.6745098233, blue: 0.9686274529, alpha: 1)
        
        return v1;

    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    
}

